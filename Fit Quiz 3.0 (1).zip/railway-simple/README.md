# ZipFit Find-My-Fit — Simple Railway deploy

Just two files. The quiz is bundled into a single self-contained `index.html`.

## What's in here
- `index.html` — the entire quiz (~1.7 MB, includes the boot database, images, and code, all inlined)
- `package.json` — tells Railway to serve the file

## Deploy to Railway in 3 minutes

1. **Make a GitHub repo** with these two files. Easiest way:
   - Go to github.com and click **New repository**.
   - Name it something like `zipfit-quiz`. Leave everything default. Click **Create**.
   - On the next page, click **uploading an existing file**.
   - Drag both `index.html` and `package.json` into the upload area.
   - Click **Commit changes**.
2. **In Railway** (railway.app):
   - **New Project → Deploy from GitHub repo** → pick the repo you just made.
   - Railway auto-detects Node and starts deploying.
3. **Get the URL**: in the Railway project, click your service → **Settings → Networking → Generate Domain**. Railway gives you a `*.up.railway.app` URL.

That's it — your quiz is live. Visit the URL to see it.

## Embedding in Shopify

In your Shopify theme editor, add a custom-HTML section to any page with:

```html
<iframe
  src="https://your-railway-url.up.railway.app/"
  loading="lazy"
  style="border:0;width:100%;height:920px;max-width:880px;display:block;margin:0 auto"
  title="Find my ZipFit"
></iframe>
```

## ⚠️ This version does NOT send data to Shopify or Odoo

The single-file build is **frontend only**. The "Save my match" form will collect the user's name and email but it won't POST anywhere — the data goes nowhere when the user clicks Continue.

When you're ready to wire Shopify + Odoo, switch to the `railway/` package (the one with `server.js`) — same Railway-deploy flow, but the backend exists to receive submissions and push them to both systems.

## Updating the quiz

The bundled `index.html` is hard to edit by hand. When you want to change the quiz, edit the source files in the `railway/public/` folder and re-bundle.
